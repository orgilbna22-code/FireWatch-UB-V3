import React, { useCallback, useState, useEffect } from 'react';
import { ActiveTab, Language, ViewMode } from './types';
import { Header } from './components/common/Header';
import { Footer } from './components/common/Footer';
import { LandingHero } from './components/landing/LandingHero';
import { LandingSections } from './components/landing/LandingSections';
import { RiskMap } from './components/map/RiskMap';
import { OverviewDashboard } from './components/dashboard/OverviewDashboard';
import { RiskExplorer } from './components/explorer/RiskExplorer';
import { DistrictAnalysis } from './components/districts/DistrictAnalysis';
import { IncidentHistory } from './components/incidents/IncidentHistory';
import { EmergencyCoverage } from './components/emergency/EmergencyCoverage';
import { RiskCalendar } from './components/calendar/RiskCalendar';
import { WeatherModule } from './components/weather/WeatherModule';
import { SafetyCenter } from './components/safety/SafetyCenter';
import { ReportCenter } from './components/reports/ReportCenter';
import { DataSourcesModal } from './components/common/DataSourcesModal';
import { AdminDataGate } from './components/common/AdminDataGate';
import { FamilyQuickView } from './components/common/FamilyQuickView';
import { FireSimulationLab } from './components/simulation/FireSimulationLab';
import { GlobalFireBackground } from './components/common/GlobalFireBackground';
import { PersonalPortal } from './components/personal/PersonalPortal';
import { MobileBottomNav } from './components/common/MobileBottomNav';
import { MobileMenuDrawer } from './components/common/MobileMenuDrawer';
import { useTheme } from './hooks/useTheme';
import { liveWeather } from './hooks/liveWeather';

const VALID_TABS: ActiveTab[] = [
  'landing', 'overview', 'map', 'explorer', 'districts', 'incidents',
  'calendar', 'emergency', 'weather', 'safety', 'reports', 'sources', 'personal',
];

function getInitialTab(): ActiveTab {
  const h = window.location.hash.replace('#', '') as ActiveTab;
  return VALID_TABS.includes(h) ? h : 'landing';
}

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>(getInitialTab);
  const [language, setLanguage] = useState<Language>('mn');
  const [viewMode, setViewMode] = useState<ViewMode>('public');
  const [selectedDistrictId, setSelectedDistrictId] = useState<string>('bayanzurkh');
  const [isDataSourcesModalOpen, setIsDataSourcesModalOpen] = useState(false);
  const [isFamilyModeOpen, setIsFamilyModeOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();

  // Single shared LIVE weather feed (Open-Meteo) for map ticker, dashboard and weather views
  useEffect(() => {
    liveWeather.start();
    return () => liveWeather.stop();
  }, []);

  // Smooth scroll to top when changing views
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeTab]);

  // Keep URL hash in sync so tabs survive refresh and can be deep-linked
  useEffect(() => {
    const target = `#${activeTab}`;
    if (window.location.hash !== target) {
      window.history.replaceState(null, '', target);
    }
  }, [activeTab]);

  useEffect(() => {
    const onHashChange = () => {
      const h = window.location.hash.replace('#', '') as ActiveTab;
      if (VALID_TABS.includes(h)) {
        setActiveTab((cur) => (cur === h ? cur : h));
      }
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  // Stable identities keep overlay key-listeners and focus timers from
  // re-registering on every App render.
  const closeMobileMenu = useCallback(() => setIsMobileMenuOpen(false), []);
  const closeSourcesModal = useCallback(() => setIsDataSourcesModalOpen(false), []);
  const closeFamilyMode = useCallback(() => setIsFamilyModeOpen(false), []);

  const handleSelectDistrictAndMap = (districtId: string) => {
    setSelectedDistrictId(districtId);
    setActiveTab('map');
  };

  const handleSelectDistrictAndDetail = (districtId: string) => {
    setSelectedDistrictId(districtId);
    setActiveTab('districts');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F8FA] text-[#12152A] antialiased selection:bg-[#FF633C]/20 selection:text-[#0B124D] relative w-full max-w-full overflow-x-hidden">
      
      {/* Omnipresent Living Ambient Fire Atmosphere Across Whole Site */}
      <GlobalFireBackground initialMode="soft" language={language} hideRibbon={activeTab === 'map'} />

      {/* Universal Top Navigation Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        language={language}
        setLanguage={setLanguage}
        viewMode={viewMode}
        setViewMode={setViewMode}
        theme={theme}
        onToggleTheme={toggleTheme}
        onOpenDemoInfo={() => setIsDataSourcesModalOpen(true)}
        onToggleFamilyMode={() => setIsFamilyModeOpen(!isFamilyModeOpen)}
        isFamilyModeOpen={isFamilyModeOpen}
        onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
      />

      {/* Optional Family & Elder Friendly Quick Modal Overlay */}
      {isFamilyModeOpen && (
        <FamilyQuickView
          language={language}
          onClose={closeFamilyMode}
          onOpenMap={() => {
            setIsFamilyModeOpen(false);
            setActiveTab('map');
          }}
        />
      )}

      {/* Main View Router with Apple-Grade Smooth Transition */}
      <main className={`flex-1 flex flex-col relative w-full max-w-full overflow-x-hidden ${activeTab === 'map' ? '' : 'pb-20 lg:pb-0'}`}>
        <div key={activeTab} className="flex-1 flex flex-col animate-fade-in">
            {activeTab === 'landing' && (
              <div className="flex-1 flex flex-col">
                <LandingHero
                  language={language}
                  onExploreMap={() => setActiveTab('map')}
                  onSelectTab={setActiveTab}
                  onOpenDemoInfo={() => setIsDataSourcesModalOpen(true)}
                  onOpenFamilyMode={() => setIsFamilyModeOpen(true)}
                />
                <LandingSections
                  language={language}
                  onSelectTab={setActiveTab}
                  onSelectDistrict={handleSelectDistrictAndDetail}
                  onOpenDemoInfo={() => setIsDataSourcesModalOpen(true)}
                />
              </div>
            )}

            {activeTab === 'overview' && (
              <OverviewDashboard
                language={language}
                viewMode={viewMode}
                onSelectTab={setActiveTab}
                onSelectDistrict={handleSelectDistrictAndMap}
                onOpenDemoInfo={() => setIsDataSourcesModalOpen(true)}
              />
            )}

            {activeTab === 'map' && (
              <RiskMap
                language={language}
                viewMode={viewMode}
                selectedDistrictId={selectedDistrictId}
                onSelectDistrict={(id) => setSelectedDistrictId(id)}
                onNavigateToDetail={handleSelectDistrictAndDetail}
              />
            )}

            {activeTab === 'explorer' && (
              <div className="space-y-8">
                <RiskExplorer
                  language={language}
                  onNavigateToMapWithDistrict={handleSelectDistrictAndMap}
                />
                <div className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto pb-12">
                  <FireSimulationLab
                    language={language}
                    onExploreMap={() => setActiveTab('map')}
                  />
                </div>
              </div>
            )}

            {activeTab === 'districts' && (
              <DistrictAnalysis
                language={language}
                initialDistrictId={selectedDistrictId}
                onNavigateToMapWithDistrict={handleSelectDistrictAndMap}
              />
            )}

            {activeTab === 'incidents' && (
              <IncidentHistory
                language={language}
                onNavigateToMapWithDistrict={handleSelectDistrictAndMap}
                onOpenDemoInfo={() => setIsDataSourcesModalOpen(true)}
              />
            )}

            {activeTab === 'emergency' && (
              <EmergencyCoverage
                language={language}
                onNavigateToMap={() => setActiveTab('map')}
              />
            )}

            {activeTab === 'calendar' && (
              <RiskCalendar language={language} />
            )}

            {activeTab === 'weather' && (
              <div className="space-y-8">
                <WeatherModule language={language} />
                <div className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto pb-12">
                  <FireSimulationLab
                    language={language}
                    onExploreMap={() => setActiveTab('map')}
                  />
                </div>
              </div>
            )}

            {activeTab === 'safety' && (
              <div className="space-y-8">
                <SafetyCenter language={language} />
                <div className="px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto pb-12">
                  <FamilyQuickView
                    language={language}
                    onOpenMap={() => setActiveTab('map')}
                  />
                </div>
              </div>
            )}

            {activeTab === 'reports' && (
              <ReportCenter language={language} />
            )}

            {activeTab === 'sources' && (
              <div className="p-4 sm:p-8 max-w-5xl mx-auto my-4 sm:my-8 space-y-6">
                <div className="bg-white/90 backdrop-blur-xl p-6 sm:p-8 rounded-3xl border border-black/[0.06] shadow-sm space-y-6">
                  <span className="text-xs font-mono font-bold text-[#FF633C] uppercase tracking-wider block">
                    GOVERNANCE &amp; DATA MANAGEMENT
                  </span>
                  <h2 className="font-editorial text-2xl sm:text-3xl font-bold text-[#0B124D]">
                    {language === 'mn' ? 'Өгөгдлийн эх сурвалж ба удирдлага' : 'Data Governance & Management'}
                  </h2>
                  <p className="text-xs sm:text-sm text-[#72778A] leading-relaxed">
                    {language === 'mn'
                      ? 'ОБЕГ, Үндэсний статистикийн хороо, ЦУОШГ-ын албан ёсны өгөгдлийг нэгтгэн орон зайн математик загварчлалаар боловсруулсан арга зүй ба өгөгдлийн сангийн удирдлага.'
                      : 'Aggregated datasets processed with open multi-variable decision analysis formulas and SQLite data management.'}
                  </p>
                  <button
                    onClick={() => setIsDataSourcesModalOpen(true)}
                    className="px-6 py-3 bg-[#0B124D] hover:bg-[#11166B] text-white text-xs font-bold rounded-2xl transition-all shadow-md active:scale-95"
                  >
                    {language === 'mn' ? 'Эх сурвалжийн самбар нээх' : 'Open Data Governance Panel'}
                  </button>
                  <div className="pt-4 border-t border-black/[0.06]">
                    <AdminDataGate language={language} />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'personal' && (
              <PersonalPortal
                language={language}
                onExploreMap={() => setActiveTab('map')}
                onSelectDistrict={handleSelectDistrictAndMap}
              />
            )}
        </div>
      </main>

      {/* Footer (Hidden on map view for full screen immersion) */}
      {activeTab !== 'map' && (
        <Footer
          language={language}
          onSelectTab={setActiveTab}
          onOpenSources={() => setIsDataSourcesModalOpen(true)}
        />
      )}

      {/* Mobile Fixed Bottom Navigation Bar (Hidden on Desktop) */}
      <MobileBottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        language={language}
        onOpenMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        isMenuOpen={isMobileMenuOpen}
      />

      {/* Mobile Slide-Over Menu Drawer */}
      <MobileMenuDrawer
        isOpen={isMobileMenuOpen}
        onClose={closeMobileMenu}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        language={language}
        setLanguage={setLanguage}
        onOpenSources={() => setIsDataSourcesModalOpen(true)}
        onToggleFamilyMode={() => setIsFamilyModeOpen(!isFamilyModeOpen)}
        isFamilyModeOpen={isFamilyModeOpen}
        theme={theme}
        onToggleTheme={toggleTheme}
      />

      {/* Data Governance & Demo Transparency Modal */}
      <DataSourcesModal
        isOpen={isDataSourcesModalOpen}
        onClose={closeSourcesModal}
        language={language}
      />

    </div>
  );
}
